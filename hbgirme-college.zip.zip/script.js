document.querySelector("form").addEventListener("submit", () => {
    alert("Admission form submitted successfully!");
});
